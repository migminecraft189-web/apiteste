# API Chatbot Tester

Aplicativo Android nativo com:
- Chat com OpenAI (`gpt-4o-mini`).
- Chat com Claude/Anthropic (`claude-sonnet-4-5`).
- Testador HTTP genérico com GET, POST, PUT e DELETE.
- Exibição do código HTTP, duração e resposta JSON.
- Chave digitada apenas em memória, sem persistência local.

## Compilar no Bitrise
1. Envie os arquivos deste projeto para `migminecraft189-web/apiteste`.
2. No Bitrise, adicione o repositório como projeto Android e escolha o workflow `primary`.
3. Execute uma build e baixe `app-debug.apk` nos artefatos.

## Segurança
Não coloque chaves no código, commits, logs ou arquivos do APK. Chaves usadas diretamente pelo app podem ser expostas. Para uso real, crie um backend que guarde a chave em variável de ambiente e faça as chamadas aos provedores pelo servidor.
